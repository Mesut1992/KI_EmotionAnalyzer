Dieses Projekt wurde in Teamarbeit von Mesut Kuscu und Helge Br�gner erstellt.

Dieser Ordner enth�lt folgendes:
- Dokumentation.pdf : Die Dokumentation des Projektes.
- Code/ : Hier kompilierbaren Codedateien enthalten. 
- Build/ : Hier ist das kompilierte Projekt als prj.exe enthalten. Die Datei wurde auf WIN7 getestet und sollte von WINDOWS System ausf�hrbar sein.
- Solution/ : Hier befindet sich die VisualStudio Solution zum Projekt

Weitere Informationen zum Projekt sind in der Dokumentation zu finden.